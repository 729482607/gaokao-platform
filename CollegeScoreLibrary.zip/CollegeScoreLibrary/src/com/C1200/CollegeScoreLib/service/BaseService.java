package com.C1200.CollegeScoreLib.service;

public class BaseService {

}
